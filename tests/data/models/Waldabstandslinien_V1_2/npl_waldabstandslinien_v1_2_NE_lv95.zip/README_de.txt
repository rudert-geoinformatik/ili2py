Detailinformationen Kanton 
---------------------------

Thema:
    Waldabstandslinien
Aktualisierungs-Zyklus:
    Wenn Nötig
Zeitstand (letzte Publikation):
    04.06.2025 11:06:04
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
