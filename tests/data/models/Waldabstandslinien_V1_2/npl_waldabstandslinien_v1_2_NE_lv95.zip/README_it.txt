Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Linee di distanza dalla foresta
Ciclo di aggiornamento:
    All’occorrenza
Stato attuale (ultima pubblicazione):
    04.06.2025 11:06:04
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
