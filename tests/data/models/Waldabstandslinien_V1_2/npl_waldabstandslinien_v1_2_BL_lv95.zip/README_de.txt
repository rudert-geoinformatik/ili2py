Detailinformationen Kanton 
---------------------------

Thema:
    Waldabstandslinien
Aktualisierungs-Zyklus:
    Wenn Nötig
Zeitstand (letzte Publikation):
    24.07.2025 11:28:07
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
