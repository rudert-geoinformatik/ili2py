Detailinformationen Kanton 
---------------------------

Thema:
    Grundwasservorkommen
Aktualisierungs-Zyklus:
    Wenn Nötig
Zeitstand (letzte Publikation):
    27.03.2025 13:20:17
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
