Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Riserva forestali 1.1
Ciclo di aggiornamento:
    Irregolare
Stato attuale (ultima pubblicazione):
    04.06.2025 11:08:42
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
