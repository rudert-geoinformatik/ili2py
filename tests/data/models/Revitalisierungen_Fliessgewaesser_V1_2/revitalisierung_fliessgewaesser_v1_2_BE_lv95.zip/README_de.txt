Detailinformationen Kanton 
---------------------------

Thema:
    
Aktualisierungs-Zyklus:
    keine Angabe
Zeitstand (letzte Publikation):
    10.01.2025 12:10:35
Bezugsrahmen der Daten:
    LV95: originär
Kantonale Vollständigkeit:
    Nein
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
