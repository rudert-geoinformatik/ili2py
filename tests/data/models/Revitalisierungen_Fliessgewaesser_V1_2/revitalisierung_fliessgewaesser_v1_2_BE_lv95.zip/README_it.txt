Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    
Ciclo di aggiornamento:
    nessuna indicazione
Stato attuale (ultima pubblicazione):
    10.01.2025 12:10:35
Quadro di riferimento dei dati:
    MN95: originario
Completezza cantonale:
    No
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
