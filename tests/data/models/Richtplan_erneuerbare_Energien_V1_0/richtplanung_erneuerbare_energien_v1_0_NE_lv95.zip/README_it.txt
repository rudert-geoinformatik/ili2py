Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Piano direttore energie rinovabile
Ciclo di aggiornamento:
    Sconosciuta
Stato attuale (ultima pubblicazione):
    17.12.2025 12:18:54
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
