Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Piano direttore energie rinovabile
Ciclo di aggiornamento:
    Sconosciuta
Stato attuale (ultima pubblicazione):
    04.06.2025 11:06:46
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
