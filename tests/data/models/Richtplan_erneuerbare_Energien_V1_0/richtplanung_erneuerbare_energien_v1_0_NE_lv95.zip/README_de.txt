Detailinformationen Kanton 
---------------------------

Thema:
    Richtplanung erneuerbare Energien
Aktualisierungs-Zyklus:
    Unbekannt
Zeitstand (letzte Publikation):
    04.06.2025 11:06:46
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
