Detailinformationen Kanton 
---------------------------

Thema:
    Kataster der belasteten Standorte
Aktualisierungs-Zyklus:
    Unregelmässig
Zeitstand (letzte Publikation):
    27.07.2025 21:05:23
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
