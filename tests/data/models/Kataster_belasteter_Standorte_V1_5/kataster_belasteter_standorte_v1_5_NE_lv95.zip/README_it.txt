Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Catasto dei siti inquinati
Ciclo di aggiornamento:
    Irregolare
Stato attuale (ultima pubblicazione):
    27.07.2025 21:05:23
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
