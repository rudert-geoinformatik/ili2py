Informations détaillées du canton 
----------------------------------

Thème:
    Cadastre des sites pollués
Cycle de mise à jour:
    irrégulière
Date de dernière publication:
    27.07.2025 21:05:23
Cadre de référence des données:
    MN95: Changement de cadre de référence avec chenyx06
Intégralité cantonale:
    Oui
Remarques:
    aucune indication
Contact:
    aucune indication
