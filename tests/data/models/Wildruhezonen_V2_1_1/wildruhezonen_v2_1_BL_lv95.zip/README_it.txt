Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Zone di tranquillità per la fauna selvatica
Ciclo di aggiornamento:
    Annuale
Stato attuale (ultima pubblicazione):
    04.06.2025 11:08:58
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
