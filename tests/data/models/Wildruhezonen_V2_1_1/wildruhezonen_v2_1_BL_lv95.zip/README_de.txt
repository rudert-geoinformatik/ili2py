Detailinformationen Kanton 
---------------------------

Thema:
    Wildruhezonen
Aktualisierungs-Zyklus:
    Jährlich
Zeitstand (letzte Publikation):
    04.06.2025 11:08:58
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
