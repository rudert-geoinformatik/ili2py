Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Catasto degli eventi naturali
Ciclo di aggiornamento:
    Sconosciuta
Stato attuale (ultima pubblicazione):
    28.07.2025 06:11:30
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
