Detailinformationen Kanton 
---------------------------

Thema:
    Naturereigniskataster
Aktualisierungs-Zyklus:
    Unbekannt
Zeitstand (letzte Publikation):
    28.07.2025 06:11:30
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
