Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Dissodamenti e rimboschimenti compensativi
Ciclo di aggiornamento:
    Settimanale
Stato attuale (ultima pubblicazione):
    26.07.2025 06:12:49
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
