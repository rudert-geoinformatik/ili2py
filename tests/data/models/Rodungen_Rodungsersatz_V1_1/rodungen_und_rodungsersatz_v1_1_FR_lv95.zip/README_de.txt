Detailinformationen Kanton 
---------------------------

Thema:
    Rodungen und Rodungsersatz
Aktualisierungs-Zyklus:
    Wöchentlich
Zeitstand (letzte Publikation):
    26.07.2025 06:12:49
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
