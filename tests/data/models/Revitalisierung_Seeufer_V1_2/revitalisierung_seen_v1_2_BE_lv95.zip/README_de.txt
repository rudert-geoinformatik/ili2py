Detailinformationen Kanton 
---------------------------

Thema:
    Planung der Revitalisierungen von Seeufern
Aktualisierungs-Zyklus:
    Unregelmässig
Zeitstand (letzte Publikation):
    04.06.2025 11:06:43
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
