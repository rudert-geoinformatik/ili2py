Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    
Ciclo di aggiornamento:
    Annuale
Stato attuale (ultima pubblicazione):
    20.12.2024 13:09:14
Quadro di riferimento dei dati:
    MN95: originario
Completezza cantonale:
    Si
Osservazioni:
    Stand 13.12.2023
Contatto:
    nessuna indicazione
