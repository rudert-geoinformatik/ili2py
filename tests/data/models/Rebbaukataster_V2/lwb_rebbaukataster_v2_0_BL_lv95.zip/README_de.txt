Detailinformationen Kanton 
---------------------------

Thema:
    
Aktualisierungs-Zyklus:
    Jährlich
Zeitstand (letzte Publikation):
    20.12.2024 13:09:14
Bezugsrahmen der Daten:
    LV95: originär
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    Stand 13.12.2023
Kontakt:
    keine Angabe
