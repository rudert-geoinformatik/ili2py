Detailinformationen Kanton 
---------------------------

Thema:
    Stromversorgungssicherheit: Netzgebiete
Aktualisierungs-Zyklus:
    Wenn Nötig
Zeitstand (letzte Publikation):
    04.06.2025 11:07:28
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
