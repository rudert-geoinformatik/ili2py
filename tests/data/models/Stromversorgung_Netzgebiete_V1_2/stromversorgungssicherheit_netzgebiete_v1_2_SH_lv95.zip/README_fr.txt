Informations détaillées du canton 
----------------------------------

Thème:
    Sécurité de l'approvisionnement en électricité: zones de desserte
Cycle de mise à jour:
    au besoin
Date de dernière publication:
    04.06.2025 11:07:28
Cadre de référence des données:
    MN95: Changement de cadre de référence avec chenyx06
Intégralité cantonale:
    Oui
Remarques:
    aucune indication
Contact:
    aucune indication
