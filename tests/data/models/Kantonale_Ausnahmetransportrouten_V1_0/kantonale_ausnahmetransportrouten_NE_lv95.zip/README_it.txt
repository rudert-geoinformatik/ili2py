Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Itinerari cantonali per trasporti eccezionali
Ciclo di aggiornamento:
    Irregolare
Stato attuale (ultima pubblicazione):
    04.06.2025 10:56:02
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
