Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Inventario dei prelievi d’acqua esistenti
Ciclo di aggiornamento:
    nessuna indicazione
Stato attuale (ultima pubblicazione):
    20.05.2025 11:00:48
Quadro di riferimento dei dati:
    MN95: originario
Completezza cantonale:
    No
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
