Detailinformationen Kanton 
---------------------------

Thema:
    Inventar der bestehenden Wasserentnahmen
Aktualisierungs-Zyklus:
    keine Angabe
Zeitstand (letzte Publikation):
    20.05.2025 11:00:48
Bezugsrahmen der Daten:
    LV95: originär
Kantonale Vollständigkeit:
    Nein
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
