Detailinformationen Kanton 
---------------------------

Thema:
    Waldreservate 2.0
Aktualisierungs-Zyklus:
    Wenn Nötig
Zeitstand (letzte Publikation):
    08.08.2025 00:33:55
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
