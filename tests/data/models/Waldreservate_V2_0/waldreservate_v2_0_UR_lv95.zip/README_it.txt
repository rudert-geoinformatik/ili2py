Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Riserva forestali 2.0
Ciclo di aggiornamento:
    All’occorrenza
Stato attuale (ultima pubblicazione):
    08.08.2025 00:33:55
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
