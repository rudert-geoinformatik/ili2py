Detailinformationen Kanton 
---------------------------

Thema:
    Waldreservate 2.0
Aktualisierungs-Zyklus:
    keine Angabe
Zeitstand (letzte Publikation):
    30.06.2025 12:56:13
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Nein
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
