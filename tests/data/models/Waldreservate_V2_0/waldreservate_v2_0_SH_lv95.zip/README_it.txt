Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Riserva forestali 2.0
Ciclo di aggiornamento:
    nessuna indicazione
Stato attuale (ultima pubblicazione):
    30.06.2025 12:56:13
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    No
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
