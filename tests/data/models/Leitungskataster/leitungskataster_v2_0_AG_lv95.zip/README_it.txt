Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Catasto delle condotte
Ciclo di aggiornamento:
    Irregolare
Stato attuale (ultima pubblicazione):
    27.07.2025 19:24:09
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    No
Osservazioni:
    Der Leitungskataster enthält nur Daten der Schweizerischen Bundesbahnen (SBB).
Contatto:
    nessuna indicazione
