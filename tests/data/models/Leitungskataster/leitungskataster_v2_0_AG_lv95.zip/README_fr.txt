Informations détaillées du canton 
----------------------------------

Thème:
    Cadastre des conduites
Cycle de mise à jour:
    irrégulière
Date de dernière publication:
    27.07.2025 19:24:09
Cadre de référence des données:
    MN95: Changement de cadre de référence avec chenyx06
Intégralité cantonale:
    Non
Remarques:
    Der Leitungskataster enthält nur Daten der Schweizerischen Bundesbahnen (SBB).
Contact:
    aucune indication
