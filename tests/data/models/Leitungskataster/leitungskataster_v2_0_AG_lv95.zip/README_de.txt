Detailinformationen Kanton 
---------------------------

Thema:
    Leitungskataster
Aktualisierungs-Zyklus:
    Unregelmässig
Zeitstand (letzte Publikation):
    27.07.2025 19:24:09
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Nein
Bemerkungen:
    Der Leitungskataster enthält nur Daten der Schweizerischen Bundesbahnen (SBB).
Kontakt:
    keine Angabe
