Detailinformationen Kanton 
---------------------------

Thema:
    Gewässerraum
Aktualisierungs-Zyklus:
    Unbekannt
Zeitstand (letzte Publikation):
    24.07.2025 05:07:58
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
