Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Spazio riservato alle acque
Ciclo di aggiornamento:
    Sconosciuta
Stato attuale (ultima pubblicazione):
    24.07.2025 05:07:58
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    Si
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
