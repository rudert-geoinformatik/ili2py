Informazioni di dettaglio Cantone NE
------------------------------------

Tema:
    Statische Waldgrenzen
Ciclo di aggiornamento:
    nessuna indicazione
Stato attuale (ultima pubblicazione):
    17.01.2024 12:05:14
Quadro di riferimento dei dati:
    MN95: originario
Completezza cantonale:
    No
Osservazioni:
    nessuna indicazione
Contatto:
    sitn@ne.ch
