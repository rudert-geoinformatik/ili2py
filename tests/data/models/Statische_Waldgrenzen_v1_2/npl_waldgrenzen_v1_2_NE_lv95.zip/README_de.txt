Detailinformationen Kanton NE
-----------------------------

Thema:
    Statische Waldgrenzen
Aktualisierungs-Zyklus:
    keine Angabe
Zeitstand (letzte Publikation):
    17.01.2024 12:05:14
Bezugsrahmen der Daten:
    LV95: originär
Kantonale Vollständigkeit:
    Nein
Bemerkungen:
    keine Angabe
Kontakt:
    sitn@ne.ch
