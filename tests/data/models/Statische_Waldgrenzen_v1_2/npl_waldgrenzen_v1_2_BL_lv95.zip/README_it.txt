Detailinformationen Kanton 
---------------------------

Thema:
    Margini statici delle foreste
Aktualisierungs-Zyklus:
    Wenn Nötig
Zeitstand (letzte Publikation):
    26.02.2025 12:04:08
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Ja
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
