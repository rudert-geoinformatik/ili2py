Informations détaillées du canton 
----------------------------------

Thème:
    Limites forestières statiques
Cycle de mise à jour:
    au besoin
Date de dernière publication:
    26.02.2025 12:04:08
Cadre de référence des données:
    MN95: Changement de cadre de référence avec chenyx06
Intégralité cantonale:
    Oui
Remarques:
    aucune indication
Contact:
    aucune indication
