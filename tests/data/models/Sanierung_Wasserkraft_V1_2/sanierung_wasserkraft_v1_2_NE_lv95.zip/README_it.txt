Informazioni di dettaglio Cantone NE
------------------------------------

Tema:
    Planung und Berichterstattung der Sanierung Wasserkraft
Ciclo di aggiornamento:
    nessuna indicazione
Stato attuale (ultima pubblicazione):
    27.06.2024 08:19:06
Quadro di riferimento dei dati:
    MN95: originario
Completezza cantonale:
    No
Osservazioni:
    nessuna indicazione
Contatto:
    sitn@ne.ch
