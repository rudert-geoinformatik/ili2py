Detailinformationen Kanton NE
-----------------------------

Thema:
    Planung und Berichterstattung der Sanierung Wasserkraft
Aktualisierungs-Zyklus:
    keine Angabe
Zeitstand (letzte Publikation):
    27.06.2024 08:19:06
Bezugsrahmen der Daten:
    LV95: originär
Kantonale Vollständigkeit:
    Nein
Bemerkungen:
    keine Angabe
Kontakt:
    sitn@ne.ch
