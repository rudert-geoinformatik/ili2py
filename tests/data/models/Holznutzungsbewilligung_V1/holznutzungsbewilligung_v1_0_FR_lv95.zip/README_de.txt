Detailinformationen Kanton 
---------------------------

Thema:
    Holznutzungsbewilligung
Aktualisierungs-Zyklus:
    keine Angabe
Zeitstand (letzte Publikation):
    24.06.2025 15:39:20
Bezugsrahmen der Daten:
    LV95: Bezugsrahmenwechsel mit chenyx06
Kantonale Vollständigkeit:
    Nein
Bemerkungen:
    keine Angabe
Kontakt:
    keine Angabe
