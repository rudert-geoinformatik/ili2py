Informazioni di dettaglio Cantone 
----------------------------------

Tema:
    Autorizzazione all’utilizzo di legname
Ciclo di aggiornamento:
    nessuna indicazione
Stato attuale (ultima pubblicazione):
    24.06.2025 15:39:20
Quadro di riferimento dei dati:
    MN95: Cambio di quadro di riferimento con chenyx06
Completezza cantonale:
    No
Osservazioni:
    nessuna indicazione
Contatto:
    nessuna indicazione
