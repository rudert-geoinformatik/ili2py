Informazioni di dettaglio Cantone UR
------------------------------------

Tema:
    Planerischer Gewässerschutz 1.2
Ciclo di aggiornamento:
    nessuna indicazione
Stato attuale (ultima pubblicazione):
    11.12.2024 08:18:16
Quadro di riferimento dei dati:
    MN95: originario
Completezza cantonale:
    No
Osservazioni:
    nessuna indicazione
Contatto:
    Lisag AG, Reussacherstrasse 30, 6460 Altdorf UR
