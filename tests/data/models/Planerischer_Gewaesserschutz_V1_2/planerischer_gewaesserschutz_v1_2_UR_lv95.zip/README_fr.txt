Informations détaillées du canton UR
------------------------------------

Thème:
    Planerischer Gewässerschutz 1.2
Cycle de mise à jour:
    aucune indication
Date de dernière publication:
    11.12.2024 08:18:16
Cadre de référence des données:
    MN95: initial
Intégralité cantonale:
    Non
Remarques:
    aucune indication
Contact:
    Lisag AG, Reussacherstrasse 30, 6460 Altdorf UR
