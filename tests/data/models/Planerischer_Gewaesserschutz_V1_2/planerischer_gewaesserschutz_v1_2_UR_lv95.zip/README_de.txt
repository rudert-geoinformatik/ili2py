Detailinformationen Kanton UR
-----------------------------

Thema:
    Planerischer Gewässerschutz 1.2
Aktualisierungs-Zyklus:
    keine Angabe
Zeitstand (letzte Publikation):
    11.12.2024 08:18:16
Bezugsrahmen der Daten:
    LV95: originär
Kantonale Vollständigkeit:
    Nein
Bemerkungen:
    keine Angabe
Kontakt:
    Lisag AG, Reussacherstrasse 30, 6460 Altdorf UR
